<?php

namespace App\Http\Controllers;


use App\Http\Requests\PaymentModalRequest;
use App\Http\Requests\PhysioModalRequest;
use App\Http\Requests\PrescriptionModalRequest;
use App\Http\Requests\SickModalRequest;
use App\Models\Medicines;
use App\Models\Payments;
use App\Models\Physio_areas;
use App\Models\Physio_certificate;
use App\Models\Physio_certificate_areas;
use App\Models\Physio_certificate_types;
use App\Models\Physio_types;
use App\Models\Prescription_medicines;
use App\Models\Prescriptions;
use App\Models\Sick_certificate;
use App\Models\User;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class FormsController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    public function index()
    {
        $areas = Physio_areas::all();
        $types = Physio_types::all();
        $medicines = Medicines::all();
        return view('forms',compact('areas','types','medicines'));
    }

    public function showPatient($nCode)
    {
        $user = User::where('national_code',$nCode)->first();
        //Log::debug($user);
        return response()->json($user);

    }

    public function store_sick_certificate(SickModalRequest $request)
    {
        Log::debug($request);

        if($request->modal_sick_patient_id == null)
        {
            Log::debug('here');

            $user = User::create([
                'national_code' => $request->modal_sick_nationalCode,
                'username' => $request->modal_sick_nationalCode,
                'name' => $request->modal_sick_name,
                'phone' => $request->modal_sick_phone,
                'email' => null,
                'password' => 1,
                'status' => 1,

            ]);
            $patient_id = $user->id;

        }else $patient_id = $request->modal_sick_patient_id;
        $res = Sick_certificate::create(
            ['user_id' => $patient_id,
                'start_date' => Sick_certificate::dateToMiladi($request->modal_sick_sdate),
                'end_date' => Sick_certificate::dateToMiladi($request->modal_sick_edate),
                'date' => Sick_certificate::dateToMiladi($request->modal_sick_date),
                'phone' => $request->modal_sick_phone,
                'description' => $request->modal_sick_description]);

        return response()->json(['code'=>200 ,'id'=>$res->id], 200);
    }

    public function store_payment(PaymentModalRequest $request)
    {
        //Log::debug($request);
        if($request->modal_payment_patient_id == null)
        {
            Log::debug('here');


            $user = User::create([
                'national_code' => $request->modal_payment_nationalCode,
                'username' => $request->modal_payment_nationalCode,
                'name' => $request->modal_payment_name,
                'phone' => $request->modal_payment_phone,
                'email' => null,
                'password' => 1,
                'status' => 1,

            ]);
            $patient_id = $user->id;

        }else $patient_id = $request->modal_payment_patient_id;

        $res = Payments::create(
            ['user_id' => $patient_id,
                'number' => $request->modal_payment_number,
                'amount' => $request->modal_payment_amount,
                'date' => Sick_certificate::dateToMiladi($request->modal_payment_date),
                'description' => $request->modal_payment_description]);
        $id = $res->id;
        return response()->json(['code'=>200,'id'=>$id],200);
    }

    public function store_physio_certificate(PhysioModalRequest $request)
    {
        Log::debug($request);
        if($request->modal_physio_patient_id == null)
        {
            Log::debug('here');

            $user = User::create([
                'national_code' => $request->modal_physio_nationalCode,
                'username' => $request->modal_physio_nationalCode,
                'name' => $request->modal_physio_name,
                'phone' => $request->modal_physio_phone,
                'email' => null,
                'password' => 1,
                'status' => 1,

            ]);
            $patient_id = $user->id;

        }else $patient_id = $request->modal_physio_patient_id;


        $physio_certificate_id = "";
        $certificate = Physio_certificate::create([
            'user_id' => $patient_id,
            'num_of_sessions' => $request->modal_physio_num_sessions,
            'date' => Sick_certificate::dateToMiladi($request->modal_physio_date),
            'description' => $request->modal_physio_description]);
        $physio_certificate_id  = $certificate->id;

        $checked_types = $request->input('modal_physio_types');
        foreach ($checked_types as $checked_type) {
            $types = Physio_certificate_types::create(
                ['physio_certificate_id' => $physio_certificate_id,
                    'physio_type_id' => $checked_type]);
//            Log::debug($types);
        }


        $checked_areas = $request->input('modal_physio_areas');
        foreach ($checked_areas as $checked_area) {
            $areas = Physio_certificate_areas::create(
                ['physio_certificate_id' => $physio_certificate_id,
                    'physio_area_id' => $checked_area]);
            Log::debug($areas);
        }

        return response()->json(['code'=>200 , 'id'=>$physio_certificate_id],200);
    }

    public function store_prescription_certificate(PrescriptionModalRequest $request){
        Log::debug($request);
        if($request->modal_prescription_patient_id == null)
        {
            //Log::debug('here');

            $user = User::create([
                'national_code' => $request->modal_prescription_nationalCode,
                'username' => $request->modal_prescription_nationalCode,
                'name' => $request->modal_prescription_name,
                'phone' => $request->modal_prescription_phone,
                'email' => null,
                'password' => 1,
                'status' => 1,
            ]);
            $patient_id = $user->id;

        }else $patient_id = $request->modal_prescription_patient_id;


        $prescription_id = "";
        $certificate = Prescriptions::create([
            'user_id' => $patient_id,
            'date' => Sick_certificate::dateToMiladi($request->modal_prescription_date),
            'description' => $request->modal_prescription_description]);
        $prescription_id  = $certificate->id;



        $checked_meds = $request->input('modal_prescription_medicines');
        foreach ($checked_meds as $checked_med) {
            $meds = Prescription_medicines::create(
                ['prescription_id' => $prescription_id,
                    'medicine_id' => $checked_med]);
//            Log::debug($types);
        }

        return response()->json(['code'=>200 , 'id'=>$prescription_id],200);
    }

    public function print_payment_a5($id){
        $payment = Payments::find($id);
        $patient = User::find($payment->user_id);
        $name = $patient->name;
        $date = Sick_certificate::dateToJalali($payment->date);
        return view('print_payment_a5',compact('payment','name','date'));
    }

    public function print_prescription_a5($id){
        $prescription = Prescriptions::find($id);
        $patient = User::find($prescription->user_id);
        $name = $patient->name;
        $medicines = $prescription->prescription_medicines;
        $date = Sick_certificate::dateToJalali($prescription->date);
        $nCode = $patient->national_code;
        return view('print_prescription_a5',compact('name','medicines','date','nCode'));
    }

    public function print_sick_a5($id){
        $sick_certificate = Sick_certificate::find($id);
        $patient = User::find($sick_certificate->user_id);
        $name = $patient->name;
        $date = Sick_certificate::dateToJalali($sick_certificate->date);
        $start_date = Sick_certificate::dateToJalali($sick_certificate->date);
        $end_date = Sick_certificate::dateToJalali($sick_certificate->date);
        $description = $sick_certificate->description;
        $nCode = $patient->national_code;
        return view('print_sick_certificate_a5',compact('name','date','nCode','start_date','end_date','description'));
    }

    public function print_physio_a5($id){
        $physio = Physio_certificate::find($id);
        $patient = User::find($physio->user_id);
        $name = $patient->name;
        $description = $physio->description;
        $num_sessions = $physio->num_of_sessions;
        $nCode = $patient->national_code;
        $areas = $physio->physio_areas;
        $physio_types = $physio->physio_types->pluck('physio_type_id');
        
//        if(Str::contains($physio_types, '4')){
//            Log::debug('true');
//        }

//        Log::debug($areas);
        $physio_types = "";
        $date = Sick_certificate::dateToJalali($physio->date);
        return view('print_physio_a5',compact('name','nCode','description','date','num_sessions','areas','physio_types'));
    }

}
