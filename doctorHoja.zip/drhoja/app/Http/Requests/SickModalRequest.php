<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SickModalRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }


    public function rules()
    {
        return [
            'modal_sick_name' => 'required',
            'modal_sick_phone' => 'required',
            'modal_sick_description' => 'required',
            'modal_sick_date' => 'required',
            'modal_sick_sdate' => 'required',
            'modal_sick_edate' => 'required',
            'modal_sick_nationalCode' => 'required',
        ];
    }
    public function messages()
    {
        return[];
    }
}
