<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }


    public function rules()
    {
        return [
            'add_user_name' => 'required',
            'add_user_nationalCode' => 'required',
            'add_user_phone' => 'required',
            'add_user_username' => 'required',
            'add_user_email' => 'required',
            'add_user_pass' => 'required_without:user_id|same:confirm-password',
            'add_user_status' => 'required',
        ];
    }
    public function messages()
    {
        return[];
    }
}
