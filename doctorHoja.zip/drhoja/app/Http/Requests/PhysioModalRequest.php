<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PhysioModalRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'modal_physio_name' => 'required',
            'modal_physio_phone' => 'required',
//            'modal_physio_select_area' => 'required',
            'modal_physio_num_sessions' => 'required',
            'modal_physio_nationalCode' => 'required',
//            'Tecar' => 'required',
//            'Galt training' => 'required',
//            'BFB' => 'required',
//            'Laser' => 'required',
//            'Manual-therapy' => 'required',
//            'DN' => 'required',
//            'Vasotrain' => 'required',
//            'IR-TENS-US-EXT-Massage' => 'required',
//            'Magnet' => 'required',
//            'Cupping-therapy' => 'required',
//            'CPM' => 'required',
//            'Shock-Wave' => 'required',
            'modal_physio_description' => 'required',
        ];
    }
    public function messages()
    {
        return[];
    }
}
