<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PrescriptionModalRequest extends FormRequest
{
    public function authorize()
    {
        return true;

    }


    public function rules()
    {
        return [
            'modal_prescription_name' => 'required',
            'modal_prescription_phone' => 'required',
            'modal_prescription_nationalCode' => 'required',
            'modal_prescription_date' => 'required',
            'modal_prescription_description' => 'required',

        ];
    }
    public function messages()
    {
        return[];
    }
}
