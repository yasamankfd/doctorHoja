<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AreaRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }


    public function rules()
    {
        return [
            'add_area_name' => 'required',
            'add_area_status' => 'required',
        ];
    }
    public function messages()
    {
        return[];
    }

}
