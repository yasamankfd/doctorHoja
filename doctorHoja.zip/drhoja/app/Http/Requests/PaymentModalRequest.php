<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PaymentModalRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'modal_payment_name' => 'required',
            'modal_payment_number' => 'required',
            'modal_payment_phone' => 'required',
            'modal_payment_amount' => 'required',
            'modal_payment_date' => 'required',
            'modal_payment_description' => 'required',
            'modal_payment_nationalCode' => 'required',
        ];
    }
    public function messages()
    {
        return[];
    }
}
