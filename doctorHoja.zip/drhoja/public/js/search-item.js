import { Carousel, initTE } from "tw-elements";
initTE({ Carousel });