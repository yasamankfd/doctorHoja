$(document).ready(function() {
    $('.selectpicker').select2();
});



$(document).ready(function() {
    $('.js-example-basic-multiple').select2();
});

