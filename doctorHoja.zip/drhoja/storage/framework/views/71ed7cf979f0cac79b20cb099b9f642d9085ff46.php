<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>انتخاب نقش</title>
    <link rel="stylesheet" href="<?php echo e(url("src/css/paper.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(url("build/tailwind.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(url("src/css/font.css")); ?>">
</head>
<body class="relative font-iran a5 landscape">
<section class="sheet padding-5mm">
    <div class="relative">
        <img src="<?php echo e(url("img/physio.jpg")); ?>" alt="" class="">
        <span class="absolute top-[110px] left-[360px] text-[10px] font-extralight"><?php echo e($name); ?></span>
        <span class="absolute top-[110px] left-28 text-[10px] font-extralight"><?php echo e($nCode); ?></span>
        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="absolute top-[145px] left-[360px] text-[10px] font-extralight"><?php echo e($area->areas->title); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <span class="absolute top-[145px] left-28 text-[10px] font-extralight"><?php echo e($num_sessions); ?></span>
        <span class="absolute top-[45px] left-16 text-[10px] font-extralight flex gap-2"><?php echo e($date); ?>

            </span>




        <img src="<?php echo e(url("img/tick.svg")); ?>" alt="" class="absolute <?php if(true): ?> <?php else: ?> hidden <?php endif; ?> top-[230px] right-[322px] w-3">












        <p class="absolute bottom-[110px] left-96 text-[10px] text-justify font-extralight"><?php echo e($description); ?></p>
        <img src="<?php echo e(url("img/emsa.png")); ?>" alt="" class="absolute bottom-[70px] left-24 w-40">
    </div>

</section>
</body>
</html>
<?php /**PATH C:\wamp64\www\doctorHoja\drhoja\resources\views/print_physio_a5.blade.php ENDPATH**/ ?>