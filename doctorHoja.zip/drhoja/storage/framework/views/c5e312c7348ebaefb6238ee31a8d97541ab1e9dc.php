<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php echo $__env->yieldContent('CDNs'); ?>


    <link rel="stylesheet" href="<?php echo e(url('/build/tailwind.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('/css/font.css')); ?>">
</head>
<?php /**PATH C:\wamp64\www\doctorHoja\drhoja\resources\views/includes/header.blade.php ENDPATH**/ ?>