<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>انتخاب نقش</title>
    <link rel="stylesheet" href="<?php echo e(url("src/css/paper.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(url("build/tailwind.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(url("src/css/font.css")); ?>">
</head>
<body class="relative font-iran a5 landscape">
<section class="sheet padding-5mm">
    <div class="relative">
        <img src="<?php echo e(url("img/1.jpg")); ?>" alt="" class="">
    </div>

</section>
<section class="sheet padding-5mm">
    <div class="relative">
        <img src="<?php echo e(url("img/1.jpg")); ?>" alt="" class="">
    </div>

</section>
</body>
</html>
<?php /**PATH C:\wamp64\www\doctorHoja\drhoja\resources\views/artroz_edu.blade.php ENDPATH**/ ?>